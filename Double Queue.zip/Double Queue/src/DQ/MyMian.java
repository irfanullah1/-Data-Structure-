package DQ;

public class MyMian {

	public static void main(String[] args) {
		DQ Q=new DQ();
	  Q.InQAtRear(4);
	  Q.InQAtRear(5);
	  Q.InQAtRear(4);
	  Q.InQAtFront(1);
	  Q.DQAtRear();
	  Q.print();

	}

}
