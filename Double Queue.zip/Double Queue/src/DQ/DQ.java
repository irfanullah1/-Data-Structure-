package DQ;

public class DQ {

	int Qs=5;//Queue Size
	int Q[]=new int[Qs];
	int Rear;
	int Front;
	int size;
	public void InQAtRear(int data) {
		Q[Rear]=data;
		Rear=(Rear+1)%Qs;
		size++;
	}
	public void DQAtRear() {
		Rear++;
		size--;
	}
	public void InQAtFront(int data) {
		Q[Front]=data;
		Front=(Front+1)%Qs;
		size++;
	}
	public void DQAtFront() {
		Front++;
		size--;
	}
	public void print() {
		for(int i=0;i<size;i++)
		{
			System.out.print("->"+Q[i]);
		}
	}
}
