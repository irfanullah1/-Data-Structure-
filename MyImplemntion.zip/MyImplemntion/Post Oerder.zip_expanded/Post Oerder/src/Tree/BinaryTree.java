package Tree;

public class BinaryTree {
	Tree Root;
	public void Insert(int k) {
		Tree NewNode=new Tree(k);
		if(Root==null) 
			Root=NewNode;
		else {
			
		TraversAndAddNode(Root,NewNode);
		
		}
		
	}
	public void TraversAndAddNode(Tree Node,Tree NewNode) 
	{
		if(NewNode.Data<Node.Data)
		{
			if(Node.left==null)
			{
				Node.left=NewNode;
				//System.out.println("Data Inserted Left:"+Node.left.Data);
			}else {
				TraversAndAddNode(Node.left,NewNode);
			}
		}else if(NewNode.Data> Node.Data) 
		{
			if(Node.right==null)
            {
				Node.right=NewNode;
			//	System.out.println("Data Inserted Right:"+Node.right.Data);
			}else
			{
				TraversAndAddNode(Node.right,NewNode);
			}
		}
		
	}
	
////////////Irfanullah////////////////////
	public void Travers() {
		if(Root!=null)
		{
		  Tree Node=Root;
		  if(Node.left==null) {
			  System.out.println("Root"+Node.Data);
		  }else
		  {
			  System.out.println("Node Visted: "+Node.Data);
			  if(Node.left !=null)
			  {
				  Traversal(Node.left);
				  
			  }
		
			  /////////////////////////Irfanullah/////////////////
			
			  if(Node.right !=null)
			  {
				  Traversal(Node.right);
				  
			  }
		  }	
		}
	}

	private void Traversal(Tree Node)
	{
		
		if(Node.left !=null)
		{
		     Traversal(Node.left);
		}
	//	System.out.println("Node Visted: "+Node.Data);
		if(Node.right !=null)
		{
			Traversal(Node.right);
		}
		 System.out.println("Node Visted: "+Node.Data);
	}

}
