package Graph2;

public class MyMian {

	public static void main(String[] args) {
		Graph Map=new Graph(2);
		Map.AddEduge(1, "MyKandahar");
		Map.AddEduge(1, "Kabul");
		System.out.println("Kbul is Conneted to Kandahar: "+Map.Connected(1, "MyKandahar"));
		

	}

}
