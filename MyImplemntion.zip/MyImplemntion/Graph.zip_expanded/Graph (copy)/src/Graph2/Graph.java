package Graph2;
import java.util.*;
public class Graph {


	LinkedList<String> Vertces[];
	Graph(int size)
	{ 
		
		Vertces =new LinkedList[size];
		for(int i=0;i<size;i++)
		{
			Vertces[i]=new LinkedList<String>();
		}
	}
	public void AddEduge(int Index,String V)
	{
		Vertces[Index].add(V);
	}
	public boolean Connected(int Index,String V)
	{
	     return	Vertces[Index].contains(V);
	}
	
}
