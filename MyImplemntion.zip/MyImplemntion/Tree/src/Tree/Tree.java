package Tree;

public class Tree {
	int data;
	Tree left, Right;
	
	Tree(int data)
	{
		this.data=data;
		this.left=null;
		this.Right=null;
		
	}

}
