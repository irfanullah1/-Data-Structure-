package DoublyLinkedList;

public class MyMian {

	public static void main(String[] args) {
		DLL list=new DLL();
		list.Insert(1);
		list.Insert(2);
		list.Insert(3);
		list.Insert(4);
//		list.InsertAtStart(4);
//		list.InsertAtStart(1);
//		list.InsertAtStart(5);
	}

}
