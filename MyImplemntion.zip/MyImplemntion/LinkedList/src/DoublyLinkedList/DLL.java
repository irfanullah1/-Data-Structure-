package DoublyLinkedList;

public class DLL {
	Node head;
	Node Tail;
	
	public void Insert(int data)
	{
		Node NewNode=new Node(data);
		if(head==null)
		{
			head=NewNode;
			System.out.print(head.data);
		}else
		{
			Node CurrNode=head;
			while(CurrNode.Next !=null)
			{
				CurrNode=CurrNode.Next;
			}
			CurrNode=Tail;
			Tail=NewNode;
			Tail.Priv=CurrNode;
			Tail.Next=null;
			
			System.out.print(Tail.data);
		
		}
		
	}
	public void InsertAtStart(int data)
	{
		Node NewNode=new Node(data);
		if(head==null)
		{
			head=NewNode;
			System.out.println(head.data);
		}else {
		NewNode.Priv=head;
		head.Next=NewNode;
	    head=NewNode;
	    NewNode.Next=null;
		System.out.println(NewNode.data);
		}
	}
}
