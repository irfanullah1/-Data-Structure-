package SlingleLinkedList;

public class SLL {
	Node head;
	Node Tail;
	public void InsertAtStart(int data)
	{
		
		Node NewNode=new Node(data);
		if(head==null)
		{
			head=NewNode;
		}
		else {
		NewNode.Next=head;
		head=NewNode;
		head.Next=null;
		System.out.println(head.data);
		}
	}
	public void InsertAtLast(int data)
	{ 
		Node NewNode=new Node(data);
		if(head==null)
		{
			head=NewNode;
			
		}else
		{
			Node CurrNode=head;
			while(CurrNode.Next !=null)
			{
				CurrNode=CurrNode.Next;
			}
			System.out.println(CurrNode.data);
			CurrNode.Next=NewNode;
			
		}
		
	}
}
