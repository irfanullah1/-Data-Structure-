package SlingleLinkedList;

public class MyMain {

	public static void main(String[] args) {
		SLL list=new SLL();
		list.InsertAtLast(4);
		list.InsertAtLast(3);
		list.InsertAtLast(5);
	

	}

}
