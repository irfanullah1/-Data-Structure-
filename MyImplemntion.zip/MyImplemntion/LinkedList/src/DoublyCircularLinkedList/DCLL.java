package DoublyCircularLinkedList;

public class DCLL {
	Node head;
	Node Tail;
	
	public void Insert(int data)
	{
		Node NewNode=new Node(data);
		if(head==null)
		{
			head=NewNode;
			System.out.print(head.data);
		}else
		{
			Node CurrNode=head;
			while(CurrNode.Next !=null)
			{
				CurrNode=CurrNode.Next;
			}
			NewNode.Priv=head;
			NewNode.Next=Tail;
			Tail=NewNode;
			Tail.Next=head;
			head.Priv=Tail;
			System.out.print(Tail.data);
		}
		
	}

	public void InsertAtStart(int data)
	{
		Node NewNode =new Node(data);
		if(head==null)
		{
			head=NewNode;
			System.out.println("head: "+head.data);
		}else
		{
			NewNode.Priv=head;
			head.Next=NewNode;
			NewNode.Next=head;
			head=NewNode;
			System.out.println(head.data);
		//	System.out.println(NewNode.Next.data);
			
		}
	}
}
