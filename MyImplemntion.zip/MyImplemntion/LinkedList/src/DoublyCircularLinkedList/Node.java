package DoublyCircularLinkedList;

public class Node {
	int data;
	Node Next;
	Node Priv;
	Node(int data)
	{
		this.data=data;
		this.Next=null;
		this.Priv=null;
	}

}
