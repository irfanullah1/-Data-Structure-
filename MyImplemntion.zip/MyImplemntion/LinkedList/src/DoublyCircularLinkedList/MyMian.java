package DoublyCircularLinkedList;

public class MyMian {

	public static void main(String[] args) {
		DCLL list=new DCLL();
		list.InsertAtStart(1);
		list.InsertAtStart(2);
		list.InsertAtStart(3);


	}

}
