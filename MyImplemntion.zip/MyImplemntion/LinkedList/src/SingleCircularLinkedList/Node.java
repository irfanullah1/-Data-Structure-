package SingleCircularLinkedList;

public class Node {

	int data;
	Node Next;
	Node(int data)
	{
		this.data=data;
		this.Next=null;
	}
}
