package SingleCircularLinkedList;

public class SCLL {
	Node head,Tail;
	
	public void Insert(int data)
	{
		Node NewNode =new Node(data);
		if(head==null)
		{
			head=NewNode;
			
			System.out.print(head.data+" ->");
		}else
		{
			Node CurrNode=head;
			while(CurrNode !=null)
			{
				CurrNode=CurrNode.Next;
			}
			
			CurrNode=Tail;
			Tail=NewNode;
			Tail.Next=head;
			System.out.print(" "+Tail.data+" ->");
			System.out.print("<-"+Tail.Next.data);
		}
	}
	public void InsertAtLast(int data)
	{
		Node NewNode=new Node(data);
		NewNode.Next=head;
		head=NewNode;
		head.Next=NewNode;
	}

}
