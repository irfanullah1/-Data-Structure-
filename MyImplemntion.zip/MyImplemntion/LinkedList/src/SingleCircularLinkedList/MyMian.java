package SingleCircularLinkedList;

public class MyMian {

	public static void main(String[] args) {
		
		SCLL list=new SCLL();
		list.Insert(1);
		list.Insert(3);
		list.Insert(4);
		list.Insert(5);
		list.InsertAtLast(3);

		
	}

}
