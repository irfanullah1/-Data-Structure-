package Tree;

public class MyMain {

	public static void main(String[] args) {

	BinaryTree BT =new BinaryTree();
	////////////////////Binary Tree///////////////////
	BT.Insert(50);
	BT.Insert(40);
	BT.Insert(30);
	BT.Insert(45);
	BT.Insert(80);
	BT.Insert(60);
	BT.Insert(85);
	//BT.Serch(80);
	BT.deleteKey(50);
	BT.Travers();
	//In the Left Maximum element be come root 



	

	
	}	
	}