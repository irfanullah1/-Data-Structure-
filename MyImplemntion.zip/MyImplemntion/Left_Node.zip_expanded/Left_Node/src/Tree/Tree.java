package Tree;

public class Tree {
	int Data;
    Tree left, right;
 
    Tree(int Data) {
        this.Data = Data;
        right = null;
        left = null;
    }

}
